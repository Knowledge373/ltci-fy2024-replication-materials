# 全国図の作図資料

このフォルダは、2024年度の介護保険料普通徴収・仮算定全国図を、行政区域データと研究採用分類から再描画するための対応表とコードです。研究分類を資料収集からやり直すものではありません。

- `map_inputs/boundary_to_insurer.csv`：行政区域から保険者等への対応表と研究採用分類。対象1,573保険者（あり375、なし1,198）。北方領土6村と7都県の所属未定地140面は分類対象外です。
- `code/rebuild_geometry.py`、`code/render_national_map.py`：行政区域の再投影・統合・作図のコード。2026年10月25日版の図に用いた対応表・コードです。
- 行政区域の元ZIP、保険者一覧の原本、根拠台帳、電話・メール記録は同梱していません。

## 出所と取得

1. 国土交通省「国土数値情報（行政区域データ）」[2024年版](https://nlftp.mlit.go.jp/ksj/gml/datalist/KsjTmplt-N03-2024.html)（2024年1月1日時点）。[元ZIP](https://nlftp.mlit.go.jp/ksj/gml/data/N03/N03-2024/N03-20240101_GML.zip) を別途取得してください。固定したSHA-256は `a03111be0fe726ff270cbc1dd16f38bc926cf814e67c8cd2e52157629d138b98` です。[CC BY 4.0](https://creativecommons.org/licenses/by/4.0/deed.ja) の記載は行政区域データに適用されます。
2. 区域と保険者の対応には、国民健康保険中央会「全国介護保険者一覧」2024年5月版（[案内](https://www.seikyu-densou.jp/D/readme.html)）を使用しました。原表の再配布を行うものではありません。

国土数値情報の行政区域を保険者等ごとに統合し、Lambert 正角円錐図法に再投影し、回転・着色・図版配置を行っています。面積による削除や元形状の単純化はしていません。元データに収録されない島まで網羅するものではありません。

## 再描画

Python 3.11 以降、システムの libgdal と整合する GDAL Python バインディング、NumPy、Matplotlib、Noto Sans CJK JP が必要です（PNG出力時は Poppler の `pdftoppm` も必要）。参照環境は GDAL 3.10.3、NumPy 2.2.4、Matplotlib 3.10.1。依存関係は `code/requirements.txt` を参照してください。元ZIPを `input/` に置き、このフォルダで実行します。

```bash
sha256sum input/N03-20240101_GML.zip
python3 code/rebuild_geometry.py \
  --n03-zip input/N03-20240101_GML.zip \
  --crosswalk map_inputs/boundary_to_insurer.csv \
  --output-dir build
python3 code/render_national_map.py \
  --geometry-db build/rebuilt_geometries.sqlite \
  --output-dir figures --formats pdf --dpi 80 \
  --audit build/render_audit.json
pdftoppm -r 300 -png -singlefile \
  figures/national_map_fy2024.pdf figures/national_map_fy2024
```

`build/geometry_summary.json` と `build/render_audit.json` で出力を点検できます。元図では集約後の地理群は1,586（分析対象1,573、対象外13）で、123,828ポリゴン、192穴、15,001,902頂点を描画に用いました。ソフトウェアの版や出力メタデータによって図版のバイト列は変わり得ます。配布する対応表・コードは `sha256sum -c MANIFEST.sha256` で照合できます。
