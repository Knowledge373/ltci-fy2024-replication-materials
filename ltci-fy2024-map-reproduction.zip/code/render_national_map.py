#!/usr/bin/env python3
"""Render a complete insurer-level national map from a separately rebuilt SQLite geometry file.

No geometry simplification, polygon deletion, or anisotropic scaling is performed.
Requires the externally acquired N03 boundary data and the supplied crosswalk;
see README.md for the separate reconstruction step and source restrictions.
"""
import argparse, csv, json, math, sqlite3, struct
from collections import Counter
from pathlib import Path
import numpy as np
from osgeo import ogr, gdal
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.artist import Artist
from matplotlib.path import Path as MplPath
from matplotlib.patches import Patch
from matplotlib.font_manager import FontProperties
from matplotlib.colors import to_rgba
from matplotlib.transforms import Affine2D
from matplotlib.backends.backend_pdf import PdfFile, Verbatim, Op
from matplotlib import _path

# PDF output rounds coordinates for storage only. Every input vertex is retained.
# Adaptive precision preserves validity, ring orientation, and per-ring area to 0.01%.
PDF_PRECISION_QA = {'paths': 0, 'decimal_places': {}, 'max_displacement_pt': 0.0, 'max_relative_ring_area_error': 0.0, 'all_rounded_geometries_valid': True}

def signed_area(v):
    z=v-v[0]
    return np.sum(z[:-1,0]*z[1:,1]-z[1:,0]*z[:-1,1])/2

def compact_path_operations(path, transform, clip=None, simplify=None, sketch=None):
    precision=6
    if getattr(path, '_source_geography', False):
        v=transform.transform(path.vertices)
        starts=np.flatnonzero(path.codes==MplPath.MOVETO)
        ends=np.r_[starts[1:],len(v)]
        original_areas=[signed_area(v[a:b]) for a,b in zip(starts,ends)]
        for precision in range(3,10):
            rounded=np.round(v,precision);rings=[rounded[a:b] for a,b in zip(starts,ends)]
            errors=[];okay=True
            for ring,original in zip(rings,original_areas):
                area=signed_area(ring)
                if original==0 or area*original<=0:
                    okay=False;break
                errors.append(abs(area-original)/abs(original))
            if not okay or max(errors)>0.0001:continue
            data=b'\x01'+struct.pack('<II',3,len(rings))+b''.join(struct.pack('<I',len(r))+np.asarray(r,dtype='<f8').tobytes() for r in rings)
            geom=ogr.CreateGeometryFromWkb(data)
            gdal.PushErrorHandler('CPLQuietErrorHandler')
            valid=bool(geom.IsValid())
            gdal.PopErrorHandler()
            if valid:break
        else:raise ValueError('No valid PDF coordinate precision for a source polygon')
        PDF_PRECISION_QA['paths']+=1
        PDF_PRECISION_QA['decimal_places'][str(precision)]=PDF_PRECISION_QA['decimal_places'].get(str(precision),0)+1
        PDF_PRECISION_QA['max_displacement_pt']=max(PDF_PRECISION_QA['max_displacement_pt'],float(np.linalg.norm(rounded-v,axis=1).max()))
        PDF_PRECISION_QA['max_relative_ring_area_error']=max(PDF_PRECISION_QA['max_relative_ring_area_error'],max(errors))
    return [Verbatim(_path.convert_to_string(path,transform,clip,False,sketch,precision,[Op.moveto.value,Op.lineto.value,b'',Op.curveto.value,Op.closepath.value],True))]

PdfFile.pathOperations=staticmethod(compact_path_operations)

W, H = 594, 420
ROTATION = -35.0
CRS = '+proj=lcc +lat_1=30 +lat_2=45 +lat_0=37.5 +lon_0=137 +datum=WGS84 +units=m +no_defs'
plt.rcParams.update({'pdf.fonttype':3, 'pdf.compression':9, 'svg.fonttype':'path', 'path.simplify':False, 'hatch.linewidth':0.55})

def polygon_path(poly):
    vs, cs = [], []
    for i, ring in enumerate(poly):
        a = np.asarray(ring.GetPoints(), dtype=np.float64)[:, :2]
        # Opposite winding of exterior and interior rings preserves all holes.
        s = np.sum(a[:-1,0] * a[1:,1] - a[1:,0] * a[:-1,1])
        if (i == 0 and s < 0) or (i > 0 and s > 0):
            a = a[::-1].copy()
        codes = np.full(len(a), MplPath.LINETO, dtype=np.uint8)
        codes[0], codes[-1] = MplPath.MOVETO, MplPath.CLOSEPOLY
        vs.append(a); cs.append(codes)
    path=MplPath(np.concatenate(vs), np.concatenate(cs));path._source_geography=True
    return path

def overlap(a,b):
    return not (a[1]<b[0] or a[0]>b[1] or a[3]<b[2] or a[2]>b[3])

class FullGeometry(Artist):
    def __init__(self, dbpath, panels):
        super().__init__(); self.dbpath, self.panels = dbpath, panels
        self.audit = {}; self.set_zorder(2)
    def draw(self, renderer):
        db = sqlite3.connect(self.dbpath)
        counts = {p['name']:Counter() for p in self.panels}
        ids = {p['name']:set() for p in self.panels}
        for p in self.panels:
            p['transform'] = Affine2D().rotate_deg(p['rotation']) + p['ax'].transData
        gcs={}
        for p in self.panels:
            for category in ('なし','あり','outside'):
                gc=renderer.new_gc(); gc.set_linewidth(p['line_pt'])
                gc.set_foreground(to_rgba('#777777' if category=='あり' else '#353535'))
                gc.set_antialiased(True);gc.set_clip_rectangle(p['ax'].bbox)
                if category=='outside':
                    gc.set_hatch('/////');gc.set_hatch_color(to_rgba('#444444'));gc.set_hatch_linewidth(.55)
                gcs[p['name'],category]=gc
        for category in ('なし','あり','outside'):
            for key, properties, wkb in db.execute('SELECT id, properties, raw_wkb FROM geometries ORDER BY id'):
                prop=json.loads(properties)
                if (prop['adoption'] or 'outside') != category:continue
                geom=ogr.CreateGeometryFromWkb(wkb)
                polygons=[geom] if geom.GetGeometryName()=='POLYGON' else geom
                for poly in polygons:
                    bounds=poly.GetEnvelope(); candidates=[p for p in self.panels if p['name']=='main' or overlap(bounds,p['limits'])]
                    if not candidates:continue
                    path=polygon_path(poly)
                    for p in candidates:
                        # A constant stroke can hide the white interior of a tiny island,
                        # even in a vector PDF. Scale its boundary stroke to its own size.
                        transformed=p['transform'].transform(path.vertices)
                        span=np.ptp(transformed,axis=0).min()
                        area_scale=np.linalg.norm(p['transform'].transform([1,0])-p['transform'].transform([0,0]))
                        feature_scale=min(span,math.sqrt(poly.Area())*area_scale)
                        thin_pt=min(p['line_pt'],feature_scale/renderer.points_to_pixels(1.0)*0.06)
                        gcs[p['name'],category].set_linewidth(thin_pt)
                        face='black' if category=='あり' else ('#e0e0e0' if category=='outside' else 'white')
                        renderer.draw_path(gcs[p['name'],category],path,p['transform'],to_rgba(face))
                        counts[p['name']]['parts']+=1;counts[p['name']]['holes']+=poly.GetGeometryCount()-1
                        counts[p['name']]['vertices']+=len(path.vertices);counts[p['name']][category]+=1
                        ids[p['name']].add(key)
        for gc in gcs.values():gc.restore()
        self.audit={p['name']:{**dict(counts[p['name']]),'group_count':len(ids[p['name']]),'group_ids':sorted(ids[p['name']])} for p in self.panels}
        db.close();self.stale=False

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--geometry-db',required=True,type=Path)
    ap.add_argument('--output-dir',required=True,type=Path);ap.add_argument('--font',default='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
    ap.add_argument('--formats',default='pdf');ap.add_argument('--dpi',type=int,default=80)
    ap.add_argument('--layout',choices=['full','detail'],default='detail');ap.add_argument('--audit',type=Path)
    args=ap.parse_args();args.output_dir.mkdir(parents=True,exist_ok=True)
    fp=FontProperties(fname=args.font);plt.rcParams['font.family']=fp.get_name()
    fig=plt.figure(figsize=(W/25.4,H/25.4),facecolor='white',dpi=args.dpi)
    def text(x,y,s,sz=11,**kw):
        return fig.text(x/W,y/H,s,fontproperties=fp,fontsize=sz,**kw)
    text(12,404,'介護保険料の仮算定の全国分布',22,weight='bold',va='baseline')
    text(12,394,'2024年度  |  研究採用分類  |  分析対象 1,573 保険者',12,va='baseline')
    text(582,405,'全国公開図  |  公開版 2026-10-25',13,ha='right',va='baseline')
    text(582,395,'N03収録範囲を省略せず表示',10,ha='right',va='baseline',color='#444444')
    fig.add_artist(plt.Line2D([12/W,582/W],[388/H,388/H],transform=fig.transFigure,lw=.7,color='#555555'))
    angle=math.radians(ROTATION);R=np.array([[math.cos(angle),-math.sin(angle)],[math.sin(angle),math.cos(angle)]])
    lo=np.array([float('inf')]*2);hi=-lo;db=sqlite3.connect(args.geometry_db);group_stats=Counter()
    for key,properties,wkb in db.execute('SELECT id, properties, raw_wkb FROM geometries'):
        prop=json.loads(properties);group_stats[prop['adoption'] or 'outside']+=1
        geom=ogr.CreateGeometryFromWkb(wkb)
        polygons=[geom] if geom.GetGeometryName()=='POLYGON' else geom
        for poly in polygons:
            a=np.asarray(poly.GetGeometryRef(0).GetPoints())[:,:2]@R.T
            lo=np.minimum(lo,a.min(0));hi=np.maximum(hi,a.max(0))
    db.close()
    assert dict(group_stats)=={'なし':1198,'あり':375,'outside':13},dict(group_stats)
    pad=(hi-lo)*.018;lo-=pad;hi+=pad
    ax=fig.add_axes([80/W,42/H,434/W,340/H]);ax.set_xlim(lo[0],hi[0]);ax.set_ylim(lo[1],hi[1]);ax.set_aspect('equal');ax.set_xticks([]);ax.set_yticks([])
    for s in ax.spines.values():s.set_visible(False)
    panels=[{'name':'main','ax':ax,'rotation':ROTATION,'line_pt':.16,'limits':[float(lo[0]),float(hi[0]),float(lo[1]),float(hi[1])]}]
    handles=[Patch(facecolor='black',edgecolor='#666666',label='仮算定あり  375（23.8%）'),Patch(facecolor='white',edgecolor='#333333',label='仮算定なし  1,198（76.2%）'),Patch(facecolor='#e0e0e0',edgecolor='#444444',hatch='/////',label='分類対象外')]
    fig.legend(handles=handles,loc='upper left',bbox_to_anchor=(13/W,376/H),frameon=False,prop=FontProperties(fname=args.font,size=12),labelspacing=1.05,handlelength=1.3,handleheight=1.15,borderaxespad=0)
    text(14,338,'対象外：北方領土6村・所属未定地\n割合は保険者数に基づく。\n着色面積の割合ではない。',9.5,va='top',linespacing=1.6,color='#444444')
    text(14,308,'閲覧方法',11,weight='bold',va='top')
    text(14,299,'PDFを拡大すると、微小な区域や\n離島の形状も確認できます。\n白は「なし」、対象外は薄灰に斜線。',9.5,va='top',linespacing=1.6,color='#444444')
    # Main arrow: projected grid north, true north on central meridian only.
    nx,ny=39,249;dx,dy=math.sin(-angle)*17,math.cos(angle)*17
    ax.annotate('',xy=((nx+dx)/W,(ny+dy)/H),xytext=(nx/W,ny/H),xycoords=fig.transFigure,textcoords=fig.transFigure,arrowprops={'arrowstyle':'-|>','lw':1.2,'color':'#222222'},annotation_clip=False)
    text(nx+dx,ny+dy+2,'N',12,ha='center');text(14,240,'主図：LCC・時計回り35°\n北矢印は投影座標の北。\n東経137°上で真北に一致。',9,va='top',linespacing=1.6,color='#444444')
    inset_settings=[]
    if args.layout=='detail':
        inset_settings=[('東京周辺',(202000,284000,-231000,-163000),512,307,70,58,20000),('大阪・神戸周辺',(-181000,-96000,-348000,-278000),512,207,70,58,20000)]
    for title,lim,x,y,w,h,scale in inset_settings:
        ia=fig.add_axes([x/W,y/H,w/W,h/H]);ia.set_xlim(lim[:2]);ia.set_ylim(lim[2:]);ia.set_aspect('equal');ia.set_xticks([]);ia.set_yticks([])
        for sp in ia.spines.values():sp.set_color('#999999');sp.set_linewidth(.5)
        text(x,y+h+6,title,12,va='baseline');text(x,y+h+1,'拡大図・北上・別縮尺',8.5,va='baseline',color='#555555')
        panels.append({'name':title,'ax':ia,'rotation':0,'line_pt':.27,'limits':list(lim),'scale_m':scale})
    geom_artist=FullGeometry(args.geometry_db,panels);fig.add_artist(geom_artist)
    # Geographic guide labels use centroids of verified, existing N03 polygon parts.
    # Each coordinate window only selects a label anchor, never filters map geometry.
    label_specs=[
        ('南西諸島','insref-1582',None,(-10,-12)),
        ('伊豆諸島','insref-0600',None,(13,5)),
        ('小笠原諸島','insref-0615',(500000,550000,-1170000,-1100000),(14,1)),
        ('沖ノ鳥島','insref-0615',(-120000,-80000,-1930000,-1880000),(14,5)),
        ('南鳥島','insref-0615',(1720000,1770000,-1330000,-1280000),(10,9))
    ]
    label_audit=[];label_db=sqlite3.connect(args.geometry_db)
    for title,key,window,offset in label_specs:
        properties,wkb=label_db.execute('SELECT properties,raw_wkb FROM geometries WHERE id=?',(key,)).fetchone()
        geo=ogr.CreateGeometryFromWkb(wkb);polys=[geo] if geo.GetGeometryName()=='POLYGON' else geo
        candidates=[p for p in polys if window is None or overlap(p.GetEnvelope(),window)]
        assert candidates,(title,key)
        poly=max(candidates,key=lambda p:p.Area());cen=poly.Centroid();raw=np.array([cen.GetX(),cen.GetY()]);point=raw@R.T
        ann=ax.annotate(title,xy=point,xycoords=ax.transData,annotation_clip=False,xytext=(offset[0]*72/25.4,offset[1]*72/25.4),textcoords='offset points',
                    fontproperties=fp,fontsize=10.5,color='#555555',ha='left',va='center',
                    arrowprops={'arrowstyle':'-','color':'#888888','lw':.55,'shrinkA':3,'shrinkB':2},zorder=4)
        ann.remove();fig.add_artist(ann)
        label_audit.append({'label':title,'source_group':key,'source_properties':json.loads(properties),'candidate_parts':len(candidates),'anchor_lcc_m':raw.tolist(),'anchor_rotated_m':point.tolist()})
    label_db.close()
    # Text lies in the page margins, outside main map and inset panels.
    notes=[
        '注：分析対象は1,573保険者（あり375、なし1,198）。地理データはこれに分類対象外13群（北方領土6村、7都県の所属未定地群）を加えた1,586群。',
        '境界は2024年1月1日、保険者構成は2024年5月版。観測単位は保険者であり、広域保険者の構成自治体を個別の保険者として数えない。',
        '元のN03に収録された区域・穴を保持して投影・統合・着色した。N03未収録の島まで網羅した図ではない。分類の定義・判定方法・出所の詳細はREADMEを参照。',
        '出所：国土交通省「国土数値情報（行政区域データ）」2024年版（CC BY 4.0）及び国民健康保険中央会「全国介護保険者一覧」2024年5月版を基に筆者作成。'
    ]
    fig.add_artist(plt.Line2D([12/W,582/W],[35/H,35/H],transform=fig.transFigure,lw=.5,color='#999999'))
    for i,n in enumerate(notes):text(12,28-i*6,n,9.5,va='baseline',color='#333333')
    geom_artist.set_visible(False);fig.canvas.draw();geom_artist.set_visible(True)
    def scale_bar(panel,x,y,length,label):
        box=panel['ax'].get_window_extent();lim=panel['limits'];actual=(box.width/fig.dpi*25.4)*length/(lim[1]-lim[0])
        fig.add_artist(plt.Line2D([x/W,(x+actual)/W],[y/H,y/H],transform=fig.transFigure,lw=1,color='black'))
        for xx in [x,x+actual]:fig.add_artist(plt.Line2D([xx/W,xx/W],[(y-.8)/H,(y+.8)/H],transform=fig.transFigure,lw=.8,color='black'))
        text(x+actual/2,y+2,label,10,ha='center',va='bottom');panel['scale_bar']={'length_m':length,'length_mm':actual}
    scale_bar(panels[0],14,210,500000,'主図 500 km')
    for p,setting in zip(panels[1:],inset_settings):scale_bar(p,setting[2]+2,setting[3]-6,setting[-1],'20 km')
    audit={'figure_mm':[W,H],'layout':args.layout,'geometry_source':'raw_wkb','boundary_stroke':'min(panel default, 6% of smaller projected span and sqrt polygon area in physical units); no lower width floor','outside_fill':'#e0e0e0 plus hatching','simplification':False,'projection':CRS,'main_rotation_degrees':ROTATION,'counts_by_group':dict(group_stats),'expected_parts':123828,'expected_holes':192,'expected_vertices':15001902,'text':notes,'geographic_labels':label_audit,'panels':[]}
    for p in panels:
        p0=p['ax'].transData.transform([0,0]);px=p['ax'].transData.transform([1,0]);py=p['ax'].transData.transform([0,1])
        ratio=float(np.linalg.norm(px-p0)/np.linalg.norm(py-p0));assert abs(ratio-1)<1e-7
        audit['panels'].append({k:v for k,v in p.items() if k not in ['ax','transform']}|{'xy_scale_ratio':ratio,'box_mm':[float(v)/fig.dpi*25.4 for v in p['ax'].get_window_extent().bounds]})
    for fmt in args.formats.split(','):
        path=args.output_dir/f'national_map_fy2024.{fmt}'
        metadata={'Title':'FY2024 LTCI provisional assessment: national insurer map','Author':'','Creator':'Research map renderer','Subject':'All N03-2024 source polygon parts and holes retained; insurer composition May 2024'} if fmt=='pdf' else None
        fig.savefig(path,dpi=args.dpi,metadata=metadata)
        print('SAVED',path.name,path.stat().st_size,flush=True)
    audit['draw_counts']=geom_artist.audit
    audit['pdf_coordinate_storage']=PDF_PRECISION_QA
    assert audit['draw_counts']['main']['parts']==123828
    assert audit['draw_counts']['main']['holes']==192
    assert audit['draw_counts']['main']['vertices']==15001902
    assert audit['draw_counts']['main']['group_count']==1586
    if args.audit:args.audit.write_text(json.dumps(audit,ensure_ascii=False,indent=2))
    plt.close(fig)
if __name__=='__main__':main()
