#!/usr/bin/env python3
"""Rebuild all dissolved insurer geometry from external N03 source and supplied map crosswalk.

The official N03 ZIP and the original insurer-list XLSX are not bundled.
No private evidence ledger or unpublished manuscript is required by this script.
"""
import argparse, csv, hashlib, json, sqlite3
from collections import Counter
from pathlib import Path
from osgeo import ogr, osr

SOURCE_SHA256='a03111be0fe726ff270cbc1dd16f38bc926cf814e67c8cd2e52157629d138b98'
CRS='+proj=lcc +lat_1=30 +lat_2=45 +lat_0=37.5 +lon_0=137 +datum=WGS84 +units=m +no_defs'

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--n03-zip',required=True,type=Path)
    ap.add_argument('--crosswalk',type=Path,default=Path(__file__).resolve().parents[1]/'map_inputs/boundary_to_insurer.csv')
    ap.add_argument('--output-dir',type=Path,default=Path('build'));args=ap.parse_args()
    digest=hashlib.file_digest(args.n03_zip.open('rb'),'sha256').hexdigest()
    if digest!=SOURCE_SHA256:raise ValueError('N03 ZIP does not match the documented 2024 source')
    rows=list(csv.DictReader(args.crosswalk.open(encoding='utf-8-sig')));bycode={r['code5']:r for r in rows}
    if len(bycode)!=len(rows):raise ValueError('Duplicate boundary codes in crosswalk')
    args.output_dir.mkdir(parents=True,exist_ok=True);rawfile=args.output_dir/'raw_projected.sqlite';outfile=args.output_dir/'rebuilt_geometries.sqlite'
    if rawfile.exists() or outfile.exists():raise FileExistsError('Use an empty output directory; existing databases are not overwritten')
    ogr.UseExceptions();ds=ogr.Open('/vsizip/'+str(args.n03_zip.resolve())+'/N03-20240101.shp');layer=ds.GetLayer()
    src=layer.GetSpatialRef().Clone();src.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    target=osr.SpatialReference();target.ImportFromProj4(CRS);target.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    tr=osr.CoordinateTransformation(src,target)
    raw=sqlite3.connect(rawfile);raw.execute('CREATE TABLE polygons(id TEXT, code TEXT, fid INTEGER, wkb BLOB)')
    props={};counts=Counter()
    for f in layer:
        code=f.GetField('N03_007');r=bycode[code];key=r['insref_id'] or 'unmatched_'+code
        props[key]={'id':key,'name':r['insurer_name'] or r['municipality'],'prefecture':r['prefecture'],'adoption':r['adoption'],'status':r['status']}
        geom=f.GetGeometryRef().Clone();geom.Transform(tr)
        raw.execute('INSERT INTO polygons VALUES (?,?,?,?)',(key,code,f.GetFID(),bytes(geom.ExportToWkb())));counts[code]+=1
    raw.commit();raw.execute('CREATE INDEX idx_id ON polygons(id)');raw.commit()
    assert set(counts)==set(bycode),'N03 and crosswalk codes differ'
    assert all(counts[c]==int(bycode[c]['source_polygon_count']) for c in counts),'N03 feature counts differ'
    assert sum(counts.values())==124133
    db=sqlite3.connect(outfile);db.execute('CREATE TABLE geometries(id TEXT PRIMARY KEY, properties TEXT, raw_wkb BLOB)')
    audit={'source_sha256':digest,'source_features':sum(counts.values()),'groups':len(props),'projection':CRS,'geometry_simplification':False,'groups_repaired':[],'parts':0,'holes':0,'vertices':0,'classifications':dict(Counter(p['adoption'] or 'outside' for p in props.values()))}
    for i,(key,p) in enumerate(props.items()):
        geom=ogr.Geometry(ogr.wkbMultiPolygon)
        for (wkb,) in raw.execute('SELECT wkb FROM polygons WHERE id=? ORDER BY rowid',(key,)):
            g=ogr.CreateGeometryFromWkb(wkb)
            if g.GetGeometryName()=='POLYGON':geom.AddGeometry(g)
            else:
                for poly in g:geom.AddGeometry(poly)
        result=geom.UnionCascaded()
        if not result.IsValid():
            result=result.MakeValid();audit['groups_repaired'].append(key)
        assert result.IsValid()
        parts=[result] if result.GetGeometryName()=='POLYGON' else result
        for poly in parts:
            audit['parts']+=1;audit['holes']+=poly.GetGeometryCount()-1
            audit['vertices']+=sum(r.GetPointCount() for r in poly)
        db.execute('INSERT INTO geometries VALUES (?,?,?)',(key,json.dumps(p,ensure_ascii=False),bytes(result.ExportToWkb())))
        if i%100==0:db.commit();print(f'Rebuilt {i+1}/{len(props)}',flush=True)
    db.commit();db.close();raw.close()
    assert audit['groups']==1586 and audit['parts']==123828 and audit['holes']==192
    assert audit['classifications']=={'なし':1198,'あり':375,'outside':13}
    (args.output_dir/'geometry_summary.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
    print('Complete:',outfile)
if __name__=='__main__':main()
