# 旧表番号と論文・補足の表番号の対応

図表そのものではなく、再計算の入口または対応データを案内します。投稿用の本文・補足PDFは収録していません。

| 旧表番号 | 対応先 | データ・計算の入口 |
| --- | --- | --- |
| 旧本文表3 | 本文表3A | [重み別の探索分析](../exploration/README.md) |
| 旧補足表S5 | 本文表2・補足表S5A | [支持幅別・モデル別の感度分析](../sensitivity/README.md) |
| 旧補足表S10 | 本文表3B | [探索分析の出力と尺度](../OUTPUT_DICTIONARY_JA.md) |
| 旧補足表S4A | 本文表4 | [追加2対比の比較データ](../contrast_extension/results/ADDITIVE_CELL16_COMPARISON.csv) |
| 旧補足表S6 | 補足表S5B | [比較群の選定と背景変数](../support_selection/README.md) |
| 旧補足表S7 | 補足表S6 | [固定幅の同等性検定](../sensitivity/README.md) |
| 旧補足表S8 | 補足表S5C | [固定モデルと予測範囲の出力](../OUTPUT_DICTIONARY_JA.md) |
| 旧補足表S9 | 補足S7 | [fractional logitの数値診断](../sensitivity/README.md) |
