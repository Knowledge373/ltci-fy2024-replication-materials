# 解析案内

- 最上位の `run_all.py --scope deterministic` は、記述統計、全国加法モデルとCR2、補助分析、固定16セルモデルと診断、比較群の選定の5部を、固定入力から計算します。
- `contrast_extension/run_cell16_additional_contrasts.py` は追加2対比の専用入口です。16セルモデルを別の数値経路でも照合し、既存加法モデルの保存値と並べます。[詳細と保存比較結果](../contrast_extension/README.md)。
- `run_all.py --scope all --r-command /path/to/R` は、[固定R環境](../sensitivity/README.md)で感度分析を加えます。Pythonのみの実行で同等性検定は再計算されません。
- 全体の処理完了は、各幅で同等性が成立したことを意味しません。固定幅ごとの結果は `THRESHOLDS.csv` にあり、PASS（通過）、NONPASS（非通過）、HOLD（保留）を区別します。保留は、所定の計算診断を判定より優先した結果です。
- [出力の読み方](../OUTPUT_DICTIONARY_JA.md) ／ [旧図表番号の対応](FIGURE_TABLE_CROSSWALK_JA.md) ／ [計算の来歴と範囲](../PROVENANCE_JA.md)
