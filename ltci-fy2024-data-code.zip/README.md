# 2024年度 介護保険料普通徴収｜納期一覧と解析コード

全国1,573保険者の普通徴収について、2024年度の通常納期を月別に確認できます。仮算定の有無は本研究の分類です。

## 保険者別の納期を調べる

- [月別納期・仮算定一覧（Excel）](data/FY2024_1573保険者_月別納期と研究分類_提出候補.xlsx)
- [月別納期・仮算定一覧（CSV）](data/FY2024_月別納期_提出候補.csv)
- [列の意味と出典](data/README_JA.md) ／ [図表番号の対応](docs/FIGURE_TABLE_CROSSWALK_JA.md)

Excelの「月別納期」シートを開き、「保険者名」列で探してください。月別の1は通常の納期あり、0はなしです。月別の収納額や、個人の納付実績を示すものではありません。仮算定は研究上の分類であり、行政による認定ではありません。

## 固定データから再計算する

[固定分析入力（1,573行・15列）](data/common_input_1573.csv)と、[変数辞書](data/analysis_data_dictionary.csv)、[分析仕様](data/baseline_model_specification.json)、計算コードを収録しています。月別一覧は固定分析入力の代わりにはなりません。

Python 3.12系で、パッケージの最上位から実行します。出力先は、まだ存在しないディレクトリにしてください。

```bash
python -m pip install -r requirements.txt
python run_all.py --out ../analysis-output --scope deterministic
python contrast_extension/run_cell16_additional_contrasts.py --out ../contrast-output
```

感度分析の同等性検定を再計算するには、別途[指定されたR環境](sensitivity/README.md)を用意します。実行状態と出力の読み方は[解析案内](docs/CURRENT_READER_GUIDE_JA.md)にまとめました。ファイルは `sha256sum -c MANIFEST.sha256` で照合できます。

## 収録範囲

投稿用原稿、個別照会の原文・連絡先・照会記録、未公開の保険者別調査回答、個人別の記録は収録していません。固定データからの計算をたどるための資料であり、最初の資料収集から分類までの全工程を再実施するものではありません。収納率の差は制度変更の因果効果を示しません。

第三者コードの出典と権利表示は[第三者資料の表示](THIRD_PARTY_NOTICES.md)を参照してください。第三者資料や研究資料全体を一括して再ライセンスするものではありません。
